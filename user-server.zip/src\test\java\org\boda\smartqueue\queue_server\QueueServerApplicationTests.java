package org.boda.smartqueue.queue_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QueueServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
