package org.boda.smartqueue.queue_server.model;

public class Ticket {
}
